package oodj_assignment;
public class OODJ_Assignment {
    public static Login first = new Login();
    public static ManagerMainPage second = new ManagerMainPage();
    public static ManagerRegistration second1 = new ManagerRegistration();
    public static Manager ManagerLogin = null;
    public static Technician TechnicianLogin = null;
public static void main(String[] args) {
     FileIO.read();
     CustomerIO.read();
}      
}
